package com.cg.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverUtil {

	private WebDriver driver;

	public WebDriver getDriver(String browserDriverName) {
		if (browserDriverName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserDriverName.equals("ie")) {
			System.setProperty("webdriver.ie.driver", "Drivers//IEDriverServer.exe");
			driver = new InternetExplorerDriver();

		} else if (browserDriverName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "Drivers//geckodriver.exe");
			FirefoxOptions options = new FirefoxOptions().setProfile(new FirefoxProfile());
			driver = new FirefoxDriver(options);

		} else {
			System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver = new ChromeDriver();
			// by default chrome driver
		}

		return driver;
	}

	public void closeDriver(WebDriver driver) {
		driver.quit();
	}

}
